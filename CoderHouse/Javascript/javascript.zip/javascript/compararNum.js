let num1 = prompt("Ingrese el primer número");
let num2 = prompt("Ingrese el segundo número ");

if (num1 > num2) {
    alert("El primero número es más grande.");
} else if (num1 < num2) {
    alert("El segundo número es más grande.");
} else if (num1 == num2) {
    alert("Ambos números son iguales");
}